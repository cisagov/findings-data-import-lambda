"""This package contains the ingestion_data_import code."""

__version__ = "1.0.0"
